Dataset from  https://github.com/chiayewken/Span-ASTE  , and the dataset is processed into train.txt and test.txt

Introduction
I only use 14/15/16res and combine them, simplify the task as a classification task.
Label the sentence with the first triplet, we only take 'NEG' and 'POS' samples, ignore the others.

e.g. original data
It also has lots of other Korean dishes that are affordable and just as yummy .#### #### ####[([6, 7], [10], 'POS'), ([6, 7], [14], 'POS')]

after process
It also has lots of other Korean dishes that are affordable and just as yummy .#### #### ####[([6, 7], [10], 'POS')


Note:
pad all sentence to maximum length=10
Use glove as word vectors "http://nlp.stanford.edu/data/glove.42B.300d.zip", the code will download it automatically the first time you use it.


#To do 
You need to observe the behaviour of the hidden states of different RNNs around the index position  (e.g. 10) (correctly predicted samples and false samples), you can use RNN/GRU/LSTM now, suggest to compare RNN and GRU because LSTM is too complicated.

Different hidden size can be tried, now is 64, we can try smaller one

