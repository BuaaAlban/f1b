#!/bin/bash
for dim in 12 16 32 64 128
do 
    for type in "pru rnn gru"
    do 
    python f1b_train.py $dim $type 
    done
done
