import torch.nn.functional as F
import torch.nn as nn
import torch


class PRU(nn.LSTM):
    def __init__(self, input_size, hidden_size, num_layers=1, bidirectional=False, proj_size=0, bias = True, batch_first=False, dropout=0, **kwargs):

        super().__init__(input_size, hidden_size, num_layers, bias, batch_first, dropout, bidirectional, proj_size)

        if bidirectional or proj_size!=0:
            raise(NotImplementedError)
        self.Drop =False
        if dropout>0:
            self.dropout= nn.Dropout(p=dropout)
            self.Drop=True

    def forward(self, x, init_states=None):
        """Assumes x is of shape (sequence, batch, feature), by default batch_first=False"""
        if self.batch_first:
            bs, seq_sz, _ = x.shape
        else:
            seq_sz, bs, _ =x.shape

        ht_layers = []
        ct_layers=[]
        if init_states is None:
            h_ts, c_ts = (torch.zeros(self.num_layers, bs, self.hidden_size).to(x.device),
                        torch.zeros(self.num_layers, bs, self.hidden_size).to(x.device))
        else:
            h_ts, c_ts = init_states

        HS = self.hidden_size
        for layer in range(self.num_layers):
            if layer!=0:
                hidden_seq = torch.cat(hidden_seq, dim=0)
                if self.batch_first:
                    x = hidden_seq.transpose(0,1).contiguous()
                else:
                    x = hidden_seq

            hidden_seq = []
            h_t = h_ts[layer,:,:]
            c_t = c_ts[layer,:,:]

            wih = getattr(self, 'weight_ih_l{}'.format(layer)).transpose(0,1)
            whh = getattr(self, 'weight_hh_l{}'.format(layer)).transpose(0,1)

            wih = wih[:,:2*self.hidden_size]
            whh = whh[:,:2*self.hidden_size]

            biasih = getattr(self, 'bias_ih_l{}'.format(layer))
            biashh = getattr(self, 'bias_hh_l{}'.format(layer))

            biasih = biasih[:2*self.hidden_size]
            biashh = biashh[:2*self.hidden_size]

            for t in range(seq_sz):
                if self.batch_first:
                    x_t = x[:, t, :]
                else:
                    x_t = x[t,:,:]

                gates_1 = x_t @ wih
                gates_2 = h_t @ whh

                gates = gates_1 + gates_2 + biasih + biashh

                r_t, c_t = (
                    F.sigmoid(gates[:, :HS]), # input
                    F.tanh(gates[:, HS:HS*2]), # forget
                )
                
                if self.Drop: 
                    c_t = self.dropout(c_t)

                h_t = (1-r_t)*h_t + r_t*c_t
                
                if self.Drop:
                    h_t = self.dropout(h_t)
                    
                hidden_seq.append(h_t.unsqueeze(0))

            ht_layers.append(h_t.unsqueeze(0))
            ct_layers.append(c_t.unsqueeze(0))

            if layer ==self.num_layers-1:
                hidden_seq = torch.cat(hidden_seq, dim=0)
                # reshape from shape (sequence, batch, feature) to (batch, sequence, feature)
                if self.batch_first:
                    hidden_seq = hidden_seq.transpose(0, 1).contiguous()
        h_t = torch.cat(ht_layers, dim=0)
        c_t = torch.cat(ct_layers, dim=0)

        return hidden_seq, (h_t, c_t)
