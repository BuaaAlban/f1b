from pru import PRU

import torch
m = PRU(2,10,3)

x= torch.ones(5,11,2)

y = m(x)
